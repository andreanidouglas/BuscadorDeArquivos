
package Login;

public class MainNew {
        public static void main(String argumentos[])
  	{
                Login aplicacao = new Login();
  		aplicacao.setVisible(true);
  	}        
}

